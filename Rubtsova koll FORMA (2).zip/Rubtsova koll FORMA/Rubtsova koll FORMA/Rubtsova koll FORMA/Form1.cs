﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rubtsova_koll_FORMA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (File.Exists("text.txt"))
            {
                Queue<string> propis = new Queue<string>();
                Queue<string> stroch = new Queue<string>();               
                string[] words = File.ReadAllText("text.txt").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);               
                foreach (string word in words)
                {
                    if (char.IsUpper(word[0]))
                    {
                        propis.Enqueue(word);
                    }
                    else
                    {
                        stroch.Enqueue(word);
                    }
                }
                listBox1.Items.Add("Прописные:");
                while (propis.Count > 0)
                {
                    listBox1.Items.Add($"\n{propis.Dequeue()}");
                }
                listBox1.Items.Add("Строчные:");
                while (stroch.Count > 0)
                {
                    listBox1.Items.Add($"\n {stroch.Dequeue()}");
                }
            }
            else MessageBox.Show("данного файла не существует");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox2.Text;            
            if (File.Exists(name + ".txt"))
            {
                if (new FileInfo(name + ".txt").Length == 0)
                {
                    listBox2.Items.Add("error");
                }
                else
                {
                    string[] form = File.ReadAllLines(name + ".txt");
                    for (int j = 0; j < form.Length; j++)
                    {
                        Stack<int> ss = new Stack<int>();
                        listBox2.Items.Add(form[j]);
                        for (int i = 0; i < form[j].Length; i++)
                        {
                            Random rnd = new Random();
                            char c = form[j][i];
                            int n = Convert.ToInt32(form[j][0].ToString());
                            if (char.IsDigit(c))
                            {
                                ss.Push(Convert.ToInt32(c.ToString()));
                            }
                            else if (c == 'm')
                            {
                                int a = rnd.Next(0, n);
                                int b = rnd.Next(0, n);
                                int result = (a - b) % 10;
                                ss.Push(result);
                            }
                            else if (c == 'p')
                            {
                                int a = rnd.Next(0, n);
                                int b = rnd.Next(0, n);
                                int rez = (a + b) % 10;
                                ss.Push(rez);
                            }
                        }
                        listBox2.Items.Add(ss.Pop());
                    }
                }
            }
            else
            {
                listBox2.Items.Add("error");
            }
        }
    }
    }      
    

